export class DropDownModelInfo {
 constructor(public id: string, public name: string,public isNa:boolean,public init:boolean,public completed:boolean,public uiVisible:boolean,public uiDispose:boolean) { }
}
