export class RssInfo {
    constructor(
        public clientId: number,
        public alienNmbr  : number

        /*public empAssessmentInit:boolean,
        public empAssessmentCompl:boolean,

        public caseMgmtInit:boolean,
        public caseMgmtCompl:boolean,

        public trnsAssistanceInit:boolean,
        public trnsAssistanceCompl:boolean,
        
        public eadAssistanceInit:boolean,
        public eadAssistanceCompl:boolean,

        public childCareAssistanceInit:boolean,
        public childCareAssistanceCompl:boolean,

        public referralToServiceInit:boolean,
        public referralToServiceCompl:boolean,

        public energyAssitanceNa:boolean,
        public energyAssitanceInit:boolean,
        public energyAssitanceCompl:boolean,

        public medicalAssitanceNa:boolean,
        public medicalAssitanceInit:boolean,
        public medicalAssitanceCompl:boolean,

        public uniformAssistanceNa:boolean,
        public uniformAssistanceInit:boolean,
        public uniformAssistanceCompl:boolean,

        public housingAssistanceNa:boolean,
        public housingAssistanceInit:boolean,
        public housingAssistanceCompl:boolean,

        public credentialEvaluationNa:boolean,
        public credentialEvaluationInit:boolean,
        public credentialEvaluationCompl:boolean,

        public proffLicAssistanceNa:boolean,
        public proffLicAssistanceInit:boolean,
        public proffLicAssistanceCompl:boolean&*/
    ){}
}

